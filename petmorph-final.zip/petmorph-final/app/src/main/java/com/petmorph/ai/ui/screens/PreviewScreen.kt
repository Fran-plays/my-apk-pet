package com.petmorph.ai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.petmorph.ai.animation.*
import com.petmorph.ai.data.model.CompanionEntity
import com.petmorph.ai.navigation.Routes
import com.petmorph.ai.overlay.OverlayPermissionHelper
import com.petmorph.ai.ui.CompanionViewModel

private data class ChatMsg(val fromUser: Boolean, val text: String, val cloud: Boolean = false)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PreviewScreen(nav: NavController, vm: CompanionViewModel, companionId: String) {
    var entity by remember { mutableStateOf<CompanionEntity?>(null) }
    var anim by remember { mutableStateOf(AnimationState.IDLE) }
    val talking by vm.talking.collectAsState()
    val animator = rememberCompanionAnimator()
    var chatInput by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMsg>() }
    var showOverlayInfo by remember { mutableStateOf(false) }
    val isPro by vm.container.subscription.isPro.collectAsState(initial = false)

    LaunchedEffect(companionId) { entity = vm.container.repository.get(companionId) }
    LaunchedEffect(anim) { animator.play(anim, talking) }
    LaunchedEffect(talking) { if (talking && anim != AnimationState.TALK) anim = AnimationState.TALK }

    val e = entity ?: run {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(e.name) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
                },
                actions = {
                    TextButton(onClick = {
                        if (OverlayPermissionHelper.hasPermission(nav.context)) {
                            com.petmorph.ai.overlay.FloatingCompanionService.start(nav.context, e.id)
                        } else showOverlayInfo = true
                    }) { Text("Make Floating") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            // Companion stage
            Box(
                Modifier.fillMaxWidth().height(260.dp),
                contentAlignment = Alignment.Center,
            ) {
                CompanionCanvas(
                    animator = animator,
                    bitmap = remember(e.processedImagePath) { vm.loadBitmap(e.processedImagePath) },
                    sizeDp = 200.dp,
                    onClick = {
                        anim = AnimationState.CLICK
                        vm.container.sounds.play(com.petmorph.ai.audio.SoundEffect.CLICK)
                    },
                    onDoubleClick = {
                        anim = AnimationState.EXCITED
                        vm.container.sounds.play(com.petmorph.ai.audio.SoundEffect.HAPPY)
                    },
                )
                if (talking) {
                    SpeechBubble(Modifier.align(Alignment.TopEnd).padding(12.dp), "Talking…")
                }
            }
            // Quick animation row
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(AnimationState.HAPPY, AnimationState.SLEEP, AnimationState.DANCE, AnimationState.JUMP)
                    .forEach { s ->
                        FilledTonalButton(onClick = { anim = s }) { Text(s.label) }
                    }
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))

            // Chat
            Text(
                "  Chat with ${e.name}${if (isPro) "" else " (offline mode — Pro unlocks cloud AI)"}",
                style = MaterialTheme.typography.labelLarge,
            )
            LazyColumn(
                Modifier.weight(1f).padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(messages) { m ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start,
                    ) {
                        Surface(
                            shape = RoundedCornerShape(
                                topStart = 16.dp, topEnd = 16.dp,
                                bottomStart = if (m.fromUser) 16.dp else 4.dp,
                                bottomEnd = if (m.fromUser) 4.dp else 16.dp,
                            ),
                            color = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.widthIn(max = 300.dp),
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text(m.text)
                                if (!m.fromUser) {
                                    Text(
                                        if (m.cloud) "☁️ cloud AI" else "📱 offline",
                                        style = MaterialTheme.typography.labelSmall,
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = chatInput, onValueChange = { chatInput = it },
                    placeholder = { Text("Say something…") },
                    modifier = Modifier.weight(1f),
                    maxLines = 2,
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    val msg = chatInput.trim()
                    if (msg.isBlank()) return@Button
                    messages.add(ChatMsg(fromUser = true, msg))
                    chatInput = ""
                    vm.chat(e, msg) { reply, cloud ->
                        messages.add(ChatMsg(fromUser = false, reply, cloud))
                    }
                }) { Text("Send") }
            }
        }
    }

    if (showOverlayInfo) {
        AlertDialog(
            onDismissRequest = { showOverlayInfo = false },
            title = { Text("Floating companion") },
            text = { Text(OverlayPermissionHelper.explainBeforeRequest()) },
            confirmButton = {
                TextButton(onClick = {
                    showOverlayInfo = false
                    OverlayPermissionHelper.requestPermission(
                        nav.context as android.app.Activity
                    )
                    nav.navigate(Routes.floatingControls(e.id))
                }) { Text("Grant permission") }
            },
            dismissButton = {
                TextButton(onClick = { showOverlayInfo = false }) { Text("Not now") }
            },
        )
    }
}

@Composable
fun SpeechBubble(modifier: Modifier = Modifier, text: String) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.tertiaryContainer,
    ) {
        Text(text, Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelMedium)
    }
}
