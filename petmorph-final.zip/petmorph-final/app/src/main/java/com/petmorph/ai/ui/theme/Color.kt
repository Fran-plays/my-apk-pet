package com.petmorph.ai.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val AccentLight = Color(0xFFFF6FA5)
val AccentDark = Color(0xFFFF8FB8)
val SurfaceDark = Color(0xFF16121E)
val SurfaceLight = Color(0xFFFFF8FB)
